GRANT ALL PRIVILEGES ON a2b_wizard.* TO 'wizard'@'%' IDENTIFIED BY 'wizard' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON a2b_wizard.* TO 'wizard'@'localhost' IDENTIFIED BY 'wizard' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON a2b_wizard.* TO 'wizard'@'localhost.localdomain' IDENTIFIED BY 'wizard' WITH GRANT OPTION;

