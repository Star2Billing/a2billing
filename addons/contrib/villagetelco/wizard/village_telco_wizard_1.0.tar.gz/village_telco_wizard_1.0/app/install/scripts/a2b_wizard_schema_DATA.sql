-- MySQL dump 10.11
--
-- Host: localhost    Database: a2b_wizard
-- ------------------------------------------------------
-- Server version	5.0.75-0ubuntu10.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `instances`
--

DROP TABLE IF EXISTS `instances`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `instances` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `language` varchar(3) NOT NULL default 'en',
  `country` varchar(3) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `customer_pool` bigint(20) NOT NULL,
  `customer_balance` float default NULL,
  `did_prefix` smallint(6) NOT NULL default '555',
  `rate_local` float default NULL,
  `voucher_logo` varchar(100) default NULL,
  `voucher_title` varchar(100) default NULL,
  `submit` varchar(10) default NULL,
  `open` tinyint(1) default '1',
  `name` varchar(100) default NULL,
  `did_id` text,
  `account_id` text,
  `language_name` varchar(50) default NULL,
  `country_name` varchar(50) default NULL,
  `currency_name` varchar(50) default NULL,
  `created` datetime default NULL,
  `modified` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `instances`
--

LOCK TABLES `instances` WRITE;
/*!40000 ALTER TABLE `instances` DISABLE KEYS */;
INSERT INTO `instances` VALUES (1,'en','ZAF','ZAR',100,10,669,0.5,'konquest.png','My Village Telco','next',1,'VillageTelco_ntsr-8720',NULL,NULL,NULL,NULL,NULL,'2009-12-08 13:46:01','2009-12-08 13:46:54');
/*!40000 ALTER TABLE `instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providers`
--

DROP TABLE IF EXISTS `providers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `providers` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `instance_id` int(11) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(250) NOT NULL,
  `margin` float NOT NULL,
  `code` varchar(100) NOT NULL,
  `active` tinyint(1) default NULL,
  `created` datetime default NULL,
  `modified` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `providers`
--

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vouchers`
--

DROP TABLE IF EXISTS `vouchers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `vouchers` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `instance_id` int(11) unsigned NOT NULL,
  `credit` float NOT NULL,
  `units` smallint(6) default NULL,
  `voucher_keys` text,
  `filename` varchar(50) default NULL,
  `created` datetime default NULL,
  `modified` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
INSERT INTO `vouchers` VALUES (1,1,10,10,'a:10:{i:0;s:15:\"414624165969901\";i:1;s:15:\"559410731541418\";i:2;s:15:\"151761969313538\";i:3;s:15:\"831558049822436\";i:4;s:15:\"189535243452877\";i:5;s:15:\"003034724259315\";i:6;s:15:\"555678649605131\";i:7;s:15:\"743422972873972\";i:8;s:15:\"071140713227536\";i:9;s:15:\"192966077662547\";}','VillageTelco_ntsr-8720_1.pdf','2009-12-08 13:46:30','2009-12-08 13:46:54'),(2,1,20,10,'a:10:{i:0;s:15:\"780961824746313\";i:1;s:15:\"033942014636689\";i:2;s:15:\"636386209666038\";i:3;s:15:\"227447600960248\";i:4;s:15:\"216079673203634\";i:5;s:15:\"869130036754759\";i:6;s:15:\"392806281157473\";i:7;s:15:\"540543006972277\";i:8;s:15:\"141713095264130\";i:9;s:15:\"224660502716449\";}','VillageTelco_ntsr-8720_2.pdf','2009-12-08 13:46:30','2009-12-08 13:47:19'),(3,1,10,10,NULL,NULL,'2009-12-08 13:46:31','2009-12-08 13:46:31'),(4,1,20,10,NULL,NULL,'2009-12-08 13:46:31','2009-12-08 13:46:31');
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-12-08 12:49:57
