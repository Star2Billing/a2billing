#!/bin/bash

echo ""
echo "Wipe out A2Billing and Wizard DataBase"
echo "-----------------------------"
echo ""

echo "Enter mysql root Password : "
read password

echo mysqladmin --user=root --password=$password mya2billing

echo "Deleting mya2billing database"
mysqladmin drop mya2billing --password=$password


echo "Creating mya2billing database"
mysqladmin create mya2billing --password=$password

echo "Createing database tables "
cat a2billing-createdb-user.sql | mysql  --password=$password mya2billing


echo "Populating tables with default data"
cat mya2billing_1.7_default.sql | mysql  --password=$password mya2billing

echo "Clean a2b_wizard tables"
cat a2b_wizard_schema_DATA.sql| mysql  --password=$password a2b_wizard




exit 0


