<?php

class HttpSocketHelper extends AppHelper {


      function getRates($uri){


   App::import('Core', 'HttpSocket');  
   $HttpSocket = new HttpSocket();  
   $request = array('uri' => $uri);  
   $result = $HttpSocket->request($request);  

   return $result;
   }

}
