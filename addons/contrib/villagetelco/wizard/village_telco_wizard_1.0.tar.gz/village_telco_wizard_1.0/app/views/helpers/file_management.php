<?php

class FileManagementHelper extends AppHelper {



  /**
     * Lists the files in a directory
     * 
     * @param string $directory the directory you wish to list the files of
     */

     function directoryList ($directory) {

        $directory = opendir($directory);

        while ($file = readdir($directory)) {
            if ($file != '.' && $file != '..' && $file!='.svn') {
                $check_list = strpos($file, '_list');
                $check_empty = strpos($file, 'empty');
                if($check_list === false && $check_empty === false) {
                    $results[] = $file;
                }
            }
        }
        
        closedir($directory);

        return $results;
    } 


}

?>