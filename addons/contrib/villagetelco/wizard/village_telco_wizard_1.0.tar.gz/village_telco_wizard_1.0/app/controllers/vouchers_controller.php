<?php

class VouchersController extends AppController{

      var $name = 'Vouchers';

      var $helpers = array('Flash','Html','Form');      


?>