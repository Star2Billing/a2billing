<?php

class TestsController extends AppController{

      var $name = 'Tests';

      function index(){

//      $this->set('results', $this->Test->query('Test', array('security_key' => md5('1234567890'))));

      $results =  $this->Test->query('Test', array('security_key' => md5('1234567890')));
      return $results; 
    

      }


      function Get_Countries(){

      $results =  $this->Test->query('Get_Currencies', array('security_key' => md5('1234567890')));
      return $results; 
    

      }

}

?>