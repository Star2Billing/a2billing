<?php
class ViewPdfController extends AppController {

	var $name = 'ViewPdf';
}
?>
