<?php

class ProvidersController extends AppController{

      var $name = 'Providers';

      var $helpers = array('Html','Form','HttpSocket');      



    function index(){

      	 $providers = Configure::read('Providers');     	     
    	 $result = $this->requestAction('soap/Get_ProvisioningList/'.base64_encode($providers));


	    //successful transaction 	     
            if (strpos($result[1],'SUCCESS')){  
		$data = unserialize($result[0]);
	  	}
    
		$this->set('data',$data);       
        	$this->render();


    }


    function view($id = null){


    if ($id!= NULL){

    $submit=false;

    
    if (!empty($this->data)){
      $submit = $this->params['form']['submit'];
      }


    if($submit == __('Add provider',true) || $submit == __('Update rates',true)){

    //create rates with margin

    $margin  	     = $this->data['Providers']['margin'];
    $rates  	     = $this->params['form']['rates'];
    $uri_rate        = $this->params['form']['uri_rate'];
    $uri_trunk       = $this->params['form']['uri_trunk'];
    $provider_name   = $this->params['form']['provider_name'];
    $description     = $this->params['form']['description'];

    if(!$margin){ $margin=0;}
    //$activation_code = $this->data['Providers']['activation_code'];
    $activation_code='foo';

    	 $result1 = $this->requestAction('soap/Get_Rates/'.base64_encode($uri_rate).'/'.$activation_code.'/'.$margin);
	 $this->log($result1[1],"instance");	     
         
	 if (strpos($result1[1],'SUCCESS')){ 
	    
	    $rates = base64_encode($result1[0]);

	    $instance = $this->Provider->getInstanceName();
	    $instance_id = $this->Provider->getInstanceId();

	    
	    //Add provider
	    if ($submit == __('Add provider',true)){

	       $result2 = $this->requestAction('soap/Create_TrunkConfig/'.$instance.'/'.base64_encode($uri_trunk).'/'.$activation_code.'/'.base64_encode($provider_name));
	       
	       $this->log($result2[1],"instance");	     

               	 if (strpos($result2[1],'SUCCESS')){ 

    	       	    $result3 = $this->requestAction('soap/Create_Rates/'.$instance.'/'.$rates);
	       	    $this->log($result3[1],"instance");	     
	    	 }
	    } else {
    	       	    $result2 = $this->requestAction('soap/Update_Rates/'.$instance.'/'.$rates);
		    
	       	    $this->log($result2[1],"instance");	     
	    }
	       	    $data=array('id' =>$instance_id,'title'=>$provider_name,'description' =>$description, 'margin' => $margin,'code' =>$activation_code,'active' => true);
	       	    $this->Provider->save($data);	

	  }

       $this->redirect(array('controller' => 'providers','action'=>''));
	
    }
    
    else {

	 
      	 $providers = Configure::read('Providers');     	     
    	 $result = $this->requestAction('soap/Get_ProvisioningList/'.base64_encode($providers));


            if (strpos($result[1],'SUCCESS')){  
		$data = unserialize($result[0]);
	  	}

		$data[$id]['provider_id']=$id;
		$data[$id]['margin']=$this->data['Providers']['margin'];
		$data[$id]['provider_names']=$this->Provider->getProviderNames();
		$this->set('data',$data[$id]);       
        	$this->render();
	}

	} //if id

	else {
	$this->redirect(array('controller'=>'providers','action'=>'index'));

	}

     

 }


}

?>