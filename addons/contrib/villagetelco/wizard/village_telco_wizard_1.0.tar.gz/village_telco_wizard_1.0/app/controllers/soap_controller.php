<?php

class SoapController extends AppController{

      var $name = 'Soap';

      var $from = 'Village Telco Wizard';



      function Authenticate_Admin($user,$pwd){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Authenticate_Admin', array('security_key' => md5($settings['Security_Key']), 'username' => $user, 'pwd' => $pwd));
      	       return $results; 

      }


      function Set_AdminPwd($user,$pwd){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Set_AdminPwd', array('security_key' => md5($settings['Security_Key']), 'username' => $user, 'pwd' => $pwd));
      	       return $results; 

      }



      function Get_Countries(){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Get_Countries', array('security_key' => md5($settings['Security_Key'])));
      	       return $results; 

      }

      function Get_Languages(){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Get_Languages', array('security_key' => md5($settings['Security_Key'])));
      	       return $results; 

      }

      function Get_Currencies(){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Get_Currencies', array('security_key' => md5($settings['Security_Key'])));
      	       return $results; 

      }

      function Get_Currencies_value($currency){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Get_Currencies_value', array('security_key' => md5($settings['Security_Key']),'currency'=> $currency));
      	       return $results; 

      }

      function Write_Notification($method,$status,$priority){

      	       $settings = Configure::read('Settings');
      	       $message = "Method '".$method."' was executed with status: ".$status; 

      	       $results =  $this->Soap->query('Write_Notification', array('security_key' => md5($settings['Security_Key']),'from' => 'wizard','subject' =>$message,'priority' =>$priority));

      	       return $results; 

      }

      function Validate_DIDPrefix($did_prefix){

      	       $settings = Configure::read('Settings');
      	       $results =  $this->Soap->query('Validate_DIDPrefix', array('security_key' => md5($settings['Security_Key']),'did_prefix' =>$did_prefix));
      	       return $results; 

      }


      function Create_Instance(){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Create_Instance', array('security_key' =>md5($settings['Security_Key']),'instance_name' =>$settings['Instance_Name']));
      	       return $results; 

      }

      function Set_InstanceDescription($instance){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Set_InstanceDescription', array('security_key' =>md5($settings['Security_Key']),'instance' =>$instance, 'description' => $settings['Instance_Description']));
      	       return $results; 

      }

      function Set_Setting($setting_key,$value){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Set_Setting', array('security_key' =>md5($settings['Security_Key']),'setting_key' =>$setting_key, 'value' => $value));
      	       return $results; 

      }

      function Get_Setting($setting_key){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Get_Setting', array('security_key' =>md5($settings['Security_Key']),'setting_key' =>$setting_key));
      	       return $results; 

      }

      function Create_DIDGroup($instance){

      $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Create_DIDGroup', array('security_key' =>md5($settings['Security_Key']),'instance' =>$instance));
      	       return $results; 

      }

      function Create_Provider($instance){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Create_Provider', array('security_key' =>md5($settings['Security_Key']),'instance' =>$instance));
      	       return $results; 

      }

      function Create_Ratecard($instance){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Create_Ratecard', array('security_key' =>md5($settings['Security_Key']),'instance' =>$instance));
      	       return $results; 

      }

      function Create_Callplan($instance,$id_ratecard){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Create_Callplan', array('security_key' =>md5($settings['Security_Key']),'instance' =>$instance,'id_ratecard' =>$id_ratecard));
      	       return $results; 

      }


      function Create_Voucher($credit,$units,$currency){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Create_Voucher', array('security_key' =>md5($settings['Security_Key']),'credit' =>$credit,'units' => $units,'currency' => $currency));
      	       return $results; 

      }

      function Create_Customer($instance,$id_callplan, $id_didgroup,$units,$balance,$currency,$language,$country){


      	       $settings = Configure::read('Settings');
      	       $config = Configure::read('Config');

      	       $results =  $this->Soap->query('Create_Customer', array('security_key' =>md5($settings['Security_Key']),'instance' =>$instance,'id_callplan' => $id_callplan, 'id_didgroup' => $id_didgroup,'units' => $units,'accountnumber_len'=>$config['accountnumber_len'],'balance' => $balance, 'activated' => $config['activated'], 'status' => $config['status'], 'simultaccess' => $config['simultaccess'],'currency' => $currency, 'typepaid' => $config['typepaid'],'sip' => $config['sip'],'iax' => $config['iax'],'language' => $language, 'voicemail_enabled' => $config['voicemail_enabled'],'country' => $country));
      	       return $results; 

      }


      function Create_DID($account_id,$id_didgroup,$rate,$did_prefix,$country){

      $config = Configure::read('Config');
      $settings = Configure::read('Settings');

      $account_id_multi = unserialize(base64_decode($account_id));

      $account_id_single = array();

      foreach ($account_id_multi as $account_tmp) {
          $account_id_single[] = $account_tmp[1];
	  }


      $results = $this->Soap->query('Create_DID',array('security_key'=>md5($settings['Security_Key']),'account_id' => $account_id_single, 'id_didgroup'=> $id_didgroup, 'rate' => $rate, 'connection_charge' => $config['connection_charge'], 'did_prefix' => $did_prefix, 'did_suffix' => $config['did_suffix'], 'country' => $country));
      return $results;


      }

      function Set_InstanceProvisioning(){

      	       $settings = Configure::read('Settings');

      	       $results =  $this->Soap->query('Set_InstanceProvisioning', array('security_key' =>md5($settings['Security_Key']),'instance'=>$instance,'provisioning'=>$provisioning));
      	       return $results; 

      }


      function Get_ProvisioningList($uri){

      	       $settings = Configure::read('Settings');
      
	       $uri = base64_decode($uri);
      	       $results =  $this->Soap->query('Get_ProvisioningList', array('security_key' =>md5($settings['Security_Key']),'provisioning_uri' => $uri));
      	       return $results; 

      }

      function Get_Rates($uri_rate, $activation_code, $margin){

      	       $settings = Configure::read('Settings');

	       $uri_rate = base64_decode($uri_rate);
	       $result = $this->Soap->query('Get_Rates',array('security_key' => md5($settings['Security_Key']),'uri_rate' => $uri_rate,'activation_code' =>$activation_code,'margin' => $margin));
	       return $result;

      }


      function Create_Rates($instance, $rates){

      	       $settings = Configure::read('Settings');
	       $rates = unserialize(base64_decode($rates));
	       $result = $this->Soap->query('Create_Rates',array('security_key' => md5($settings['Security_Key']),'instance' => $instance, 'rates' => $rates));
	       return $result;

      }

      function Create_TrunkConfig($instance, $uri_trunk, $activation_code,$provider_name){

      	       $settings = Configure::read('Settings');  
	       $result = $this->Soap->query('Create_TrunkConfig',array('security_key' => md5($settings['Security_Key']),'instance' => $instance, 'uri_trunk' => base64_decode($uri_trunk),'activation_code' =>$activation_code,'provider_name' =>base64_decode($provider_name)));
	       return $result;
       }

      function Update_Rates($instance, $rates){

      	       $settings = Configure::read('Settings');
	       $rates = unserialize(base64_decode($rates));
	       $result = $this->Soap->query('Update_Rates',array('security_key' => md5($settings['Security_Key']),'instance' => $instance, 'rates' => $rates));
	       return $result;

      }


}

?>