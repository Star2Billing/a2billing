<?
class ViewPdf extends AppModel {

    var $name = 'ViewPdf';

    var $useTable = false;


}
?>
