<?
class Provider extends AppModel {

    var $name = 'Provider';

    var $belongsTo = array('Instance');


    function getInstanceName(){

    	     $result = $this->query("select name from instances where open=false");
    	     return $result[0]['instances']['name'];
    }


    function getInstanceId(){

    	     $result = $this->query("select id from instances where open=false");
    	     return $result[0]['instances']['id'];
    }


   function getProviderNames(){

	$provider_name = array();
	$providers     = array(); 	 
   	$providers = $this->find('all');


	if(is_array($providers)){
 
	 foreach($providers as $provider){
	
	 	$provider_name[]=$provider['Provider']['title'];
	  		    
	 }

	 return $provider_name;

	} else {
	 
		return false;
	}

    }



}
?>
