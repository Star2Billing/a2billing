<?
class Voucher extends AppModel {

    var $name = 'Voucher';

    var $belongsTo = array('Instance');


      var $validate = array(
        'credit' => array(
            'rule'     => 'numeric',
            'message'  => 'Please select a credit.' ),
        'units' => array(
            'rule'     => 'numeric',
            'message'  => 'Please select a unit.' ));
	    

}
?>
