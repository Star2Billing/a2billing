<?
class Test extends AppModel {

    var $name = 'Test';

    var $useDbConfig = 'soap';
    var $useTable = false;


}
?>
