<?
class Soap extends AppModel {

    var $name = 'Soap';

    var $useDbConfig = 'soap';
    var $useTable = false;


}
?>
