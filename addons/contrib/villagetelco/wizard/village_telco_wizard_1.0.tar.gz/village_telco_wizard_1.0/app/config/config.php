<?php
$config['Settings'] = array(
	    'Security_Key'	   => 'Ae87v56zzl34v',
	    'Default_Pwd' 	   => 'changepassword',
	    'Instance_Name' 	   => 'VillageTelco',
	    'Instance_Description' => 'This instance has been created with the Village Telco Wizard',
	    'Logo_Dir'   	   => '/var/www/wizard/app/webroot/img/logo/');

$config['Config'] = array(
	    'accountnumber_len'	   => 7,
	    'activated'		   => true,
	    'status'		   => 1,
	    'simultaccess'	   => 0,
	    'typepaid'		   => 0,
	    'sip'		   => 1,
	    'iax'		   => 1,
    	    'voicemail_enabled'    => true,
	    'connection_charge'	   => 0,
	    'did_suffix'	   => '0000');


$config['Pdf'] = array(
	    'title'	           => 'A2Billing Vouchers',
	    'subject'		   => 'A2Billing Vouchers for Village Telco',
	    'author'		   => 'A2Billing Wizard',
	    'creator'		   => 'A2Billing Wizard',
	    'font'		   => 'dejavusans',
	    'path'		   => '/var/www/wizard/app/webroot/pdf/');

$config['Providers'] = 'http://www.call-labs.com/provisioning.txt';
?>