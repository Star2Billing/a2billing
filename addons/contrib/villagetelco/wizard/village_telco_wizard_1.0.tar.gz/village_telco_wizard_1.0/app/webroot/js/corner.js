$(document).ready(function() {
$(".main").corner();
  }); 
$(document).ready(function() {
$(".providers").corner();
  }); 
$(document).ready(function() {
$(".navigation").corner();
  }); 
$(document).ready(function() {
$(".step_default").corner();
  }); 
$(document).ready(function() {
$(".step_highlight").corner();
  }); 
$(document).ready(function() {
$(".button").corner('5px');
  }); 
